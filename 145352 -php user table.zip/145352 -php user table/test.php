  <!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>
    <body>
      <?php
      $servername = "localhost";
      $username = "root";
      $password = "";
      $database="e_commerce_test";

      $conn = mysqli_connect($servername , $username , $password, $database);
      
      if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";
  
      //execute the SQL query and return records
      //$result = mysql_query("SELECT * FROM table_one ");
      $sql="SELECT Fullname, UserName, User_email, TelNo, pass_wd FROM USERS_TABLE"; 
      $result=$conn -> query($sql);
      if ($result->num_rows > 0) {
  //print_r($result);
  $row=$result->fetch_assoc();
  
}
      ?>
      <table border="2" style= "background-color: #D8BFD8; color: #761a9b; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Full Name</th>
          <th>User Name</th>
          <th>User Email</th>
          <th>Telephone</th>
          <th>Password</th>
          <td>Action</td>
        </tr>
      </thead>
      <tbody>
        <?php
         require_once("viewdb.php");
       foreach ($test as $key => $value){
         ?>
            <tr>
              <td><?php echo $value ["Fullname"]?></td>
              <td><?php echo $value ["UserName"]?></td>
              <td><?php echo $value ["User_email"]?></td>
              <td><?php echo $value ["TelNo"]?></td>
              <td><?php echo $value ["pass_wd"]?></td>
              <td><a href=viewdb.php?edit = " <?php echo $value["UserName"] ?>">Edit</a></td>"
        <?php }  
       ?>
      </tbody>
    </table>
    
    </body>
    </html>